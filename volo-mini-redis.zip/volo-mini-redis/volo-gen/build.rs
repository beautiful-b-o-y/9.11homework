fn main() {
    volo_build::ConfigBuilder::default().write().unwrap();
}
